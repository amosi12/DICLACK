import makeWASocket from '@whiskeysockets/baileys';

export default {
  name: 'buttonz',
  aliases: ['btn'],
  description: 'Displays a list selection menu',
  run: async (context) => {
    const { client, m } = context;

    try {
      await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
      await client.sendMessage(m.chat, {
        text: `📋 *MENU*\n━━━━━━━━━━━━━━━━\nChoose an option from the list:\n━━━━━━━━━━━━━━━━\n© bmb tech`,
        footer: 'NOVA-XMD Bot',
        sections: [
          {
            title: 'General Commands',
            rows: [
              { title: 'Help', rowId: '.help', description: 'Get bot commands' },
              { title: 'Ping', rowId: '.ping', description: 'Check bot speed' },
              { title: 'Info', rowId: '.info', description: 'View bot details' }
            ]
          },
          {
            title: 'Fun Commands',
            rows: [
              { title: 'Random Fact', rowId: '.fact', description: 'Get a fun fact' },
              { title: 'Joke', rowId: '.joke', description: 'Hear a joke' }
            ]
          }
        ],
        buttonText: 'Open Menu',
        headerType: 1,
        viewOnce: true
      });

    } catch (error) {
    await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
      console.error(`Menu command error: ${error.stack}`);
    }
  }
};
